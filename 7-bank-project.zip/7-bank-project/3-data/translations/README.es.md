# [Tema de la lección]

! [Insertar un video aquí](video-url)

## [Prueba previa a la conferencia](https://ashy-river-0debb7803.1.azurestaticapps.net/quiz/45)

[Describe lo que aprenderemos]

### Introducción

Describe lo que se cubrirá

- XHR y buscar
- Análisis JSON
- visualización de datos
- plantilla de fila de tabla

- asignación: comentario + código de refactorización
- desafío: hazlo bonito

> Notas

### Requisito previo

¿Qué pasos deberían haberse cubierto antes de esta lección?

### Preparación

Pasos preparatorios para comenzar esta lección

---

[Recorrer el contenido en bloques]

## [Tema 1]

### Tarea:

Trabajen juntos para mejorar progresivamente su base de código para construir el proyecto con código compartido:

`` `html
bloques de código
''

✅ Comprobación de conocimientos: aproveche este momento para ampliar el conocimiento de los estudiantes con preguntas abiertas

## [Tema 2]

## [Tema 3]

🚀 Desafío: agregue un desafío para que los estudiantes trabajen en colaboración en clase para mejorar el proyecto

Opcional: agregue una captura de pantalla de la interfaz de usuario de la lección completa si corresponde

## [Prueba posterior a la conferencia](https://ashy-river-0debb7803.1.azurestaticapps.net/quiz/46)

## Revisión y autoestudio

**Vencimiento de la asignación [MM/AA]**: [Nombre de la asignación](assignment.es.md)
